import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import * as Notifications from 'expo-notifications';
import {useState, useEffect} from 'react';
import HomeScreen from './screens/HomeScreen';
import LoginScreen from './screens/LoginScreen';
import ProductsScreen from './screens/ProductsScreen';
import DetailsScreen from './screens/DetailsScreen';
import CartProvider from './context/CartContext';
import CartScreen from './screens/CartScreen';
import ProfileScreen from './screens/ProfileScreen';
import OrdersScreen from './screens/OrdersScreen';
import MapScreen from './screens/MapScreen';
import RestaurantDetailsScreen from './screens/RestaurantDetailsScreen';
import CheckoutScreen from './screens/CheckoutScreen';
import SettingsScreen from './screens/SettingsScreen';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const Stack = createNativeStackNavigator();

export default function App() {
  const [temaEscuro, setTemaEscuro] = useState(false);
  const [user, setUser] = useState(null);
  useEffect(() => {
  async function requestPermissions() {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      console.log('Permissão negada');
      return;
    }
    console.log('Permissão concedida!');
  }
  requestPermissions();
}, []);

  return (
   <NavigationContainer>
      {user ? (
        <AppStack setUser={setUser}  temaEscuro={temaEscuro} 
  setTemaEscuro={setTemaEscuro} />
      ) : (
        <AuthStack setUser={setUser} />
      )}
    </NavigationContainer>
   );
 }
function AuthStack({ setUser }) {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Login">
        {(props) => <LoginScreen {...props} setUser={setUser} />}
      </Stack.Screen>
    </Stack.Navigator>
  );}

  function AppStack({ setUser, temaEscuro, setTemaEscuro }) {
  return (
    <CartProvider>
      <Stack.Navigator>
        <Stack.Screen name="Home">
          {(props) => (
            <HomeScreen {...props} setUser={setUser} temaEscuro={temaEscuro} />
          )}
        </Stack.Screen>

        <Stack.Screen name="Settings">
          {(props) => (
            <SettingsScreen
              {...props}
              temaEscuro={temaEscuro}
              setTemaEscuro={setTemaEscuro}
            />
          )}
        </Stack.Screen>
        <Stack.Screen name="Products">
          {(props) => (
            <ProductsScreen {...props} temaEscuro={temaEscuro} />
          )}
        </Stack.Screen>
        <Stack.Screen name="Details">
          {(props) => <DetailsScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
        <Stack.Screen name="Cart">
          {(props) => <CartScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
        <Stack.Screen name="Profile">
          {(props) => <ProfileScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
        <Stack.Screen name="Orders">
          {(props) => <OrdersScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
        <Stack.Screen name="Map">
          {(props) => <MapScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
        <Stack.Screen name="RestaurantDetails">
          {(props) => (
            <RestaurantDetailsScreen {...props} temaEscuro={temaEscuro} />
          )}
        </Stack.Screen>
        <Stack.Screen name="Checkout">
          {(props) => <CheckoutScreen {...props} temaEscuro={temaEscuro} />}
        </Stack.Screen>
      </Stack.Navigator>
    </CartProvider>
  );
}