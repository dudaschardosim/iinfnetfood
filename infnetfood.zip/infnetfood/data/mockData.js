export const categorias = [
  { id: '1', nome: 'Lanches' },
  { id: '2', nome: 'Bebidas' },
  { id: '3', nome: 'Sobremesas' },
  { id: '4', nome: 'Pizzas' },
  { id: '5', nome: 'Japonesa' },
  { id: '6', nome: 'Massas' },
  { id: '7', nome: 'Churrasco' },
];

export const produtos = {
  Lanches: [
    { id: '1', nome: 'Hambúrguer', preco: 25 },
    { id: '2', nome: 'X-Bacon', preco: 30 },
  ],
  Bebidas: [
    { id: '3', nome: 'Refrigerante', preco: 8 },
    { id: '4', nome: 'Suco Natural', preco: 10 },
  ],
  Sobremesas: [
    { id: '5', nome: 'Sorvete', preco: 12 },
    { id: '6', nome: 'Bolo', preco: 15 },
  ],
  Pizzas: [
    { id: '7', nome: 'Pizza Calabresa', preco: 40 },
    { id: '8', nome: 'Pizza Mussarela', preco: 38 },
  ],
  Japonesa: [
    { id: '9', nome: 'Sushi', preco: 50 },
    { id: '10', nome: 'Temaki', preco: 35 },
  ],
  Massas: [
    { id: '11', nome: 'Lasanha', preco: 45 },
    { id: '12', nome: 'Macarrão', preco: 30 },
  ],
  Churrasco: [
    { id: '13', nome: 'Picanha', preco: 70 },
    { id: '14', nome: 'Costela', preco: 60 },
  ],
};