export const restaurantes = [
  {
    id: '1',
    nome: 'Confeitaria Colombo',
    endereco: 'Rua Gonçalves Dias, 32 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Confeitaria+Colombo+Centro+RJ',
    cardapio: [
      { nome: 'Café com leite', preco: 10 },
      { nome: 'Pastel de nata', preco: 12 },
    ],
  },
  {
    id: '2',
    nome: 'Amarelinho da Cinelândia',
    endereco: 'Praça Floriano, 55 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Amarelinho+Cinelândia',
    cardapio: [
      { nome: 'Chopp', preco: 12 },
      { nome: 'Filé com fritas', preco: 45 },
    ],
  },
  {
    id: '3',
    nome: 'Bar Luiz',
    endereco: 'Rua da Carioca, 39 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Bar+Luiz+Centro+RJ',
    cardapio: [
      { nome: 'Salsichão alemão', preco: 30 },
      { nome: 'Chopp escuro', preco: 14 },
    ],
  },
  {
    id: '4',
    nome: 'Casa Paladino',
    endereco: 'Rua Uruguaiana, 19 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Casa+Paladino+RJ',
    cardapio: [
      { nome: 'Sanduíche de pernil', preco: 20 },
      { nome: 'Cerveja artesanal', preco: 18 },
    ],
  },
  {
    id: '5',
    nome: 'Rio Scenarium',
    endereco: 'Rua do Lavradio, 20 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Rio+Scenarium',
    cardapio: [
      { nome: 'Feijoada', preco: 55 },
      { nome: 'Caipirinha', preco: 20 },
    ],
  },
  {
    id: '6',
    nome: 'Café Tero',
    endereco: 'Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Café+Tero+RJ',
    cardapio: [
      { nome: 'Café especial', preco: 14 },
      { nome: 'Pão de queijo', preco: 8 },
    ],
  },
  {
    id: '7',
    nome: 'Galeto Liceu',
    endereco: 'Rua Evaristo da Veiga, 35 - Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Galeto+Liceu',
    cardapio: [
      { nome: 'Galeto completo', preco: 40 },
      { nome: 'Arroz e farofa', preco: 15 },
    ],
  },
  {
    id: '8',
    nome: 'Boteco Carioquinha',
    endereco: 'Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Boteco+Carioquinha+RJ',
    cardapio: [
      { nome: 'Bolinho de bacalhau', preco: 25 },
      { nome: 'Cerveja gelada', preco: 10 },
    ],
  },
  {
    id: '9',
    nome: 'Gula Gula Centro',
    endereco: 'Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Gula+Gula+Centro+RJ',
    cardapio: [
      { nome: 'Salada com frango', preco: 35 },
      { nome: 'Suco natural', preco: 12 },
    ],
  },
  {
    id: '10',
    nome: 'Habib’s Centro',
    endereco: 'Centro, RJ',
    mapaUrl: 'https://www.google.com/maps/search/?api=1&query=Habibs+Centro+RJ',
    cardapio: [
      { nome: 'Esfiha', preco: 5 },
      { nome: 'Kibe', preco: 7 },
    ],
  },
];