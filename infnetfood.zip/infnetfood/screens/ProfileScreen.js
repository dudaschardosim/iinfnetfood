import { View, Text, StyleSheet } from 'react-native';

export default function ProfileScreen({ temaEscuro }) {
  const usuario = {
    nome: 'Eduarda Safons',
    email: 'eduardasafons@email.com',
  };

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Perfil</Text>
      <View style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}>
        <Text style={[styles.label, temaEscuro && { color: '#ccc' }]}>Nome:</Text>
        <Text style={[styles.valor, temaEscuro && { color: '#fff' }]}>{usuario.nome}</Text>
      </View>
      <View style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}>
        <Text style={[styles.label, temaEscuro && { color: '#ccc' }]}>E-mail:</Text>
        <Text style={[styles.valor, temaEscuro && { color: '#fff' }]}>{usuario.email}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  titulo: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#eee',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    color: '#555',
  },
  valor: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});