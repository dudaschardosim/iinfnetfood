import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { restaurantes } from '../data/restaurants';

export default function MapScreen({ navigation, temaEscuro }) {

  function abrirMapa() {
    Linking.openURL('https://www.google.com/maps/search/restaurantes+centro+rio+de+janeiro');
  }

  function renderItem({ item }) {
    return (
      <TouchableOpacity
        style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}
        onPress={() => navigation.navigate('RestaurantDetails', { restaurante: item })}>
        <Text style={[styles.nome, temaEscuro && { color: '#fff' }]}>{item.nome}</Text>
        <Text style={temaEscuro && { color: '#ccc' }}>{item.endereco}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Mapa</Text>
      <Image source={require('../assets/mapa.png')} style={styles.mapa}/>
      <TouchableOpacity
        style={[styles.botao, temaEscuro && { backgroundColor: '#ff6b6b' }]}
        onPress={abrirMapa}>
        <Text style={[styles.botaoTexto, temaEscuro && { color: '#fff' }]}>Ver no Google Maps</Text>
      </TouchableOpacity>
      <FlatList
        data={restaurantes}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: { fontSize: 22, marginBottom: 10 },
  mapa: {
    width: '100%',
    height: 200,
    marginBottom: 10,
    borderRadius: 10,
  },
  botao: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 8,
    marginBottom: 15,
  },
  botaoTexto: {
    color: '#fff',
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#eee',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  nome: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});