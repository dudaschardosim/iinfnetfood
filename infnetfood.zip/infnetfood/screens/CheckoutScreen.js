import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { buscarCEP } from '../services/api';
import { useState } from 'react';
import * as Notifications from 'expo-notifications';

export default function CheckoutScreen({ route, navigation, temaEscuro }) {
  const { carrinho } = route.params;
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [pagamento, setPagamento] = useState('');
  const total = carrinho.reduce(
    (sum, item) => sum + item.preco * item.quantidade, 0);
  const [erroEndereco, setErroEndereco] = useState('');
  const [erroPagamento, setErroPagamento] = useState('');
  const [sucesso, setSucesso] = useState(false);
  const [loading, setLoading] = useState(false);
  async function handleBuscarCEP(value) {
  setCep(value);

  if (value.length === 8) {
    const dados = await buscarCEP(value);

    if (dados) {
      setEndereco(`${dados.logradouro}, ${dados.bairro}, ${dados.localidade}`);
    } else {
      setErroEndereco('CEP inválido');
    }
  }
}
async function enviarNotificacao() {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Pedido confirmado!',
      body: 'Seu pedido está sendo preparado.',
    },
    trigger: null,
  });
}

  async function finalizarPedido() {
  let valido = true;
  if (!endereco) {
    setErroEndereco('Informe o endereço');
    valido = false;
  } else setErroEndereco('');
  if (!pagamento) {
    setErroPagamento('Informe o pagamento');
    valido = false;
  } else setErroPagamento('');
  if (!valido) return;
  setLoading(true);
  await new Promise(resolve => setTimeout(resolve, 1500));
  setLoading(false);
  setSucesso(true);
  setTimeout(() => {
    navigation.navigate('Home');
  }, 1500);
  await enviarNotificacao();
}

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Checkout</Text>
      <Text style={[styles.subtitulo, temaEscuro && { color: '#fff' }]}>Resumo do Pedido:</Text>
      {carrinho.map((item, index) => (
        <Text key={index} style={temaEscuro && { color: '#fff' }}>
          {item.nome} x{item.quantidade} - R$ {item.preco * item.quantidade}
        </Text>))}
      <Text style={[styles.total, temaEscuro && { color: '#fff' }]}>Total: R$ {total}</Text>
      <TextInput
        placeholder="Endereço de entrega"
        placeholderTextColor={temaEscuro ? '#bbb' : '#888'}
        style={[styles.input, temaEscuro && { backgroundColor: '#1E1E1E', color: '#fff' }, erroEndereco ? styles.inputErro : null]}
        value={endereco}
        onChangeText={(text) => { setEndereco(text); setErroEndereco(''); }}/>
      {erroEndereco ? <Text style={styles.erro}>{erroEndereco}</Text> : null}
      <TextInput
        placeholder="Digite o CEP"
        placeholderTextColor={temaEscuro ? '#bbb' : '#888'}
        style={[styles.input, temaEscuro && { backgroundColor: '#1E1E1E', color: '#fff' }]}
        value={cep}
        onChangeText={handleBuscarCEP}/>
      <TextInput
        placeholder="Método de pagamento (ex: Cartão)"
        placeholderTextColor={temaEscuro ? '#bbb' : '#888'}
        style={[styles.input, temaEscuro && { backgroundColor: '#1E1E1E', color: '#fff' }, erroPagamento ? styles.inputErro : null]}
        value={pagamento}
        onChangeText={(text) => { setPagamento(text); setErroPagamento(''); }}/>
      {erroPagamento ? <Text style={styles.erro}>{erroPagamento}</Text> : null}
      {loading && <Text style={styles.processando}>Processando pedido...</Text>}
      {sucesso && <Text style={styles.sucesso}>Pedido realizado com sucesso!</Text>}
      <TouchableOpacity
        style={[styles.botao, temaEscuro && { backgroundColor: '#333' }]}
        onPress={finalizarPedido}
        disabled={loading}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>
          {loading ? "Processando..." : "Finalizar Pedido"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: { fontSize: 24, marginBottom: 15 },
  subtitulo: { fontSize: 18, marginBottom: 10 },
  total: { fontSize: 18, marginVertical: 10 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    color: '#000',
  },
  inputErro: { borderColor: 'red' },
  erro: { color: 'red', marginBottom: 10 },
  processando: { color: 'orange', fontSize: 16, marginBottom: 10, textAlign: 'center' },
  sucesso: { color: 'green', fontSize: 18, marginBottom: 10, textAlign: 'center' },
  botao: {
    backgroundColor: '#ff6b6b',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  textoBotao: { color: '#fff', fontWeight: 'bold' },
});