import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useContext } from 'react';
import { CartContext } from '../context/CartContext';

export default function CartScreen({ navigation, temaEscuro }) {
  const {
    cart,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
  } = useContext(CartContext);

  const total = cart.reduce(
    (soma, item) => soma + item.preco * item.quantidade,
    0
  );

  function renderItem({ item }) {
    return (
      <View style={[styles.card, temaEscuro && { backgroundColor: '#1E1E1E' }]}>
        <Text style={[styles.nome, temaEscuro && { color: '#fff' }]}>{item.nome}</Text>
        <View style={styles.linha}>
          <TouchableOpacity 
            style={[styles.botaoQtd, temaEscuro && { backgroundColor: '#333' }]} 
            onPress={() => decreaseQuantity(item.id)}>
            <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>-</Text>
          </TouchableOpacity>
          <Text style={[styles.qtd, temaEscuro && { color: '#fff' }]}>{item.quantidade}</Text>
          <TouchableOpacity 
            style={[styles.botaoQtd, temaEscuro && { backgroundColor: '#333' }]} 
            onPress={() => increaseQuantity(item.id)}>
            <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>+</Text>
          </TouchableOpacity>
        </View>
        <Text style={temaEscuro && { color: '#fff' }}>R$ {item.preco * item.quantidade}</Text>
        <TouchableOpacity 
          style={[styles.removerBotao, temaEscuro && { backgroundColor: '#aa3333' }]} 
          onPress={() => removeFromCart(item.id)}>
          <Text style={styles.textoBotao}>Remover</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Carrinho</Text>
      <FlatList
        data={cart}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 20 }}/>
      <Text style={[styles.total, temaEscuro && { color: '#fff' }]}>Total: R$ {total}</Text>
      <TouchableOpacity 
        style={[styles.checkoutBotao, temaEscuro && { backgroundColor: '#333' }]} 
        onPress={() => navigation.navigate('Checkout', { carrinho: cart })}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>Ir para Checkout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: { fontSize: 24, marginBottom: 15 },
  card: {
    backgroundColor: '#eee',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
  },
  nome: { fontSize: 18, marginBottom: 10 },
  linha: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  qtd: { marginHorizontal: 15, fontSize: 18 },
  botaoQtd: {
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 5,
  },
  removerBotao: {
    backgroundColor: '#ff6b6b',
    padding: 8,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 8,
  },
  checkoutBotao: {
    backgroundColor: '#ff6b6b',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  textoBotao: {
    color: '#fff',
    fontWeight: 'bold',
  },
  total: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: 'bold',
  },
});