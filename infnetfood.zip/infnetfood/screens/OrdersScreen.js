import { View, Text, FlatList, StyleSheet } from 'react-native';

export default function OrdersScreen({ temaEscuro }) {
  const pedidos = [
    { id: '1', itens: ['Hambúrguer', 'Refrigerante'], total: 33, status: 'Em preparo!' },
    { id: '2', itens: ['Pizza Calabresa'], total: 40, status: 'Saiu para entrega!' },
    { id: '3', itens: ['Sushi', 'Temaki'], total: 85, status: 'Entregue!' },
  ];

  function renderItem({ item }) {
    return (
      <View style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}>
        <Text style={[styles.id, temaEscuro && { color: '#fff' }]}>Pedido #{item.id}</Text>
        <Text style={[styles.itens, temaEscuro && { color: '#ccc' }]}>
          Itens: {item.itens.join(', ')}
        </Text>
        <Text style={temaEscuro && { color: '#ccc' }}>Total: R$ {item.total}</Text>
        <Text style={[styles.status, temaEscuro && { color: '#ff6b6b' }]}>{item.status}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Meus Pedidos</Text>
      <FlatList
        data={pedidos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: {
    fontSize: 24,
    marginBottom: 15,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#eee',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  id: { fontSize: 16, fontWeight: 'bold' },
  itens: { marginVertical: 5 },
  status: { marginTop: 5, fontWeight: 'bold' },
});