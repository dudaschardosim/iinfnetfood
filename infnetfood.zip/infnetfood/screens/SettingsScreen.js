import { View, Text, Switch, StyleSheet } from 'react-native';

export default function SettingsScreen({ temaEscuro, setTemaEscuro }) {
  return (
    <View style={[
      styles.container,
      temaEscuro && styles.dark
    ]}>
      <Text style={[
        styles.titulo,
        temaEscuro && styles.textoDark
      ]}>
        Configurações
      </Text>
      <View style={styles.row}>
        <Text style={temaEscuro && styles.textoDark}>
          Tema escuro
        </Text>
        <Switch
          value={temaEscuro}
          onValueChange={setTemaEscuro}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  dark: {
    backgroundColor: '#121212',
  },
  titulo: {
    fontSize: 24,
    marginBottom: 20,
  },
  textoDark: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});