import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { categorias } from '../data/mockData';

export default function HomeScreen({ navigation, temaEscuro }) {

  function renderItem({ item }) {
    return (
      <TouchableOpacity
        style={[styles.card, temaEscuro && { backgroundColor: '#1E1E1E' }]}
        onPress={() => navigation.navigate('Products', { categoria: item.nome })}
      >
        <Text style={[styles.texto, temaEscuro && { color: '#fff' }]}>{item.nome}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <TouchableOpacity 
        style={[styles.botao, temaEscuro && { backgroundColor: '#333' }]} 
        onPress={() => navigation.navigate('Profile')}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>Perfil</Text>
      </TouchableOpacity>
      <TouchableOpacity 
        style={[styles.botao, temaEscuro && { backgroundColor: '#333' }]} 
        onPress={() => navigation.navigate('Orders')}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>Meus pedidos</Text>
      </TouchableOpacity>
      <TouchableOpacity 
        style={[styles.botao, temaEscuro && { backgroundColor: '#333' }]} 
        onPress={() => navigation.navigate('Map')}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>Ver mapa</Text>
      </TouchableOpacity>
      <TouchableOpacity 
        style={[styles.botao, temaEscuro && { backgroundColor: '#333' }]} 
        onPress={() => navigation.navigate('Settings')}>
        <Text style={[styles.textoBotao, temaEscuro && { color: '#fff' }]}>Configurações</Text>
      </TouchableOpacity>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Categorias</Text>
      <FlatList 
        data={categorias} 
        keyExtractor={(item) => item.id} 
        renderItem={renderItem} 
        contentContainerStyle={{ paddingBottom: 20 }}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  titulo: {
    fontSize: 24,
    marginBottom: 15,
    textAlign: 'center',
    padding: 8,
  },
  card: {
    backgroundColor: '#eee',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
  },
  texto: {
    fontSize: 18,
    color: '#000',
  },
  botao: {
    backgroundColor: '#ff6b6b',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  textoBotao: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  }, 
});