import { useState, useContext } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { CartContext } from '../context/CartContext';

export default function DetailsScreen({ route, navigation, temaEscuro }) {
  const { produto } = route.params;
  const [quantidade, setQuantidade] = useState(1);
  const { addToCart } = useContext(CartContext);

  function adicionar() {
    addToCart(produto, quantidade);
    navigation.navigate('Cart');
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.nome, temaEscuro && { color: '#fff' }]}>{produto.nome}</Text>
      <Text style={[styles.preco, temaEscuro && { color: '#fff' }]}>R$ {produto.preco}</Text>
      <View style={styles.linha}>
        <TouchableOpacity
          style={[styles.qtdBtn, temaEscuro && { backgroundColor: '#333' }]}
          onPress={() => quantidade > 1 && setQuantidade(quantidade - 1)}>
          <Text style={[styles.qtdBtnText, temaEscuro && { color: '#fff' }]}>-</Text>
        </TouchableOpacity>
        <Text style={[styles.qtd, temaEscuro && { color: '#fff' }]}>{quantidade}</Text>
        <TouchableOpacity
          style={[styles.qtdBtn, temaEscuro && { backgroundColor: '#333' }]}
          onPress={() => setQuantidade(quantidade + 1)}>
          <Text style={[styles.qtdBtnText, temaEscuro && { color: '#fff' }]}>+</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        style={[styles.botao, temaEscuro && { backgroundColor: '#ff6b6b' }]} onPress={adicionar}>
        <Text style={[styles.botaoTexto, temaEscuro && { color: '#fff' }]}>
          Adicionar ao carrinho
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  nome: { fontSize: 24, marginBottom: 10 },
  preco: { fontSize: 20, marginBottom: 20 },
  linha: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  qtdBtn: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    backgroundColor: '#ddd',
    borderRadius: 8,
  },
  qtdBtnText: { fontSize: 18, fontWeight: 'bold' },
  qtd: { marginHorizontal: 20, fontSize: 18 },
  botao: {
    backgroundColor: '#ff6b6b',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});