import { View, Text, StyleSheet, Button, Linking, Alert } from 'react-native';

export default function RestaurantDetailsScreen({ route, temaEscuro }) {
  const { restaurante } = route.params;

  function abrirMapa() {
    Linking.canOpenURL(restaurante.mapaUrl)
      .then((supported) => {
        if (supported) {
          return Linking.openURL(restaurante.mapaUrl);
        } else {
          Alert.alert('Erro', 'Não foi possível abrir o mapa');
        }
      })
      .catch(() => Alert.alert('Erro ao abrir mapa'));
  }
  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.nome, temaEscuro && { color: '#fff' }]}>{restaurante.nome}</Text>
      <Text style={[styles.info, temaEscuro && { color: '#ccc' }]}>
        {restaurante.endereco}
      </Text>
      <Button title="Ver no mapa" onPress={abrirMapa} />
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>Cardápio</Text>
      {restaurante.cardapio.map((item, index) => (
        <View key={index} style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}>
          <Text style={temaEscuro && { color: '#fff' }}>{item.nome}</Text>
          <Text style={temaEscuro && { color: '#fff' }}>R$ {item.preco}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  nome: { fontSize: 24, marginBottom: 10 },
  info: { marginBottom: 10 },
  titulo: {
    fontSize: 20,
    marginTop: 20,
    marginBottom: 10,
  },
  card: {
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 8,
    marginBottom: 8,
  },
});