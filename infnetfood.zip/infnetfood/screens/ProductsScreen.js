import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { produtos } from '../data/mockData';

export default function ProductsScreen({ route, navigation, temaEscuro }) {
  const { categoria } = route.params;
  const listaProdutos = produtos[categoria];

  function renderItem({ item }) {
    return (
      <TouchableOpacity
        style={[styles.card, temaEscuro && { backgroundColor: '#333' }]}
        onPress={() => navigation.navigate('Details', { produto: item })}>
        <Text style={[styles.nome, temaEscuro && { color: '#fff' }]}>{item.nome}</Text>
        <Text style={temaEscuro && { color: '#ccc' }}>R$ {item.preco}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.container, temaEscuro && { backgroundColor: '#121212' }]}>
      <Text style={[styles.titulo, temaEscuro && { color: '#fff' }]}>{categoria}</Text>
      <FlatList
        data={listaProdutos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: { fontSize: 22, marginBottom: 15 },
  card: {
    backgroundColor: '#eee',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  nome: { fontSize: 18 },
});